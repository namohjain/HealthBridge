import React from "react";
import "../App.css";

const Appointments = () => {
  const upcoming = [
    { date: "2024-06-15", time: "10:00 AM", doctor: "Dr. Smith" },
    { date: "2024-07-01", time: "2:00 PM", doctor: "Dr. Brown" },
  ];

  return (
    <div className="card appointments">
      <h2 className="section-title">Upcoming Appointments</h2>
      <ul>
        {upcoming.map((appt, idx) => (
          <li key={idx}>
            <strong>{appt.date} at {appt.time}</strong> with {appt.doctor}
          </li>
        ))}
      </ul>
    </div>
  );
};

export default Appointments;

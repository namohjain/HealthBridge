import React from "react";
import "../App.css";

const Notifications = () => {
  const messages = [
    "New message from Dr. Smith.",
    "Lab results available for review.",
    "Reminder: Appointment on June 15.",
  ];

  return (
    <div className="card notifications">
      <h2 className="section-title">Notifications</h2>
      <ul>
        {messages.map((msg, idx) => (
          <li key={idx}>{msg}</li>
        ))}
      </ul>
    </div>
  );
};

export default Notifications;

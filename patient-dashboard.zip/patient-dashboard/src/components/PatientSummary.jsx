import React from "react";
import "../App.css";

const PatientSummary = () => {
  return (
    <div className="card">
      <h2 className="section-title">Patient Summary</h2>
      <p><strong>Name:</strong> John Doe</p>
      <p><strong>Age:</strong> 34</p>
      <p><strong>Gender:</strong> Male</p>
      <p><strong>Blood Type:</strong> O+</p>
    </div>
  );
};

export default PatientSummary;

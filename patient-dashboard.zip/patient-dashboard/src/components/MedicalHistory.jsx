import React from "react";
import "../App.css";

const MedicalHistory = () => {
  const records = [
    { date: "2024-02-10", description: "Annual Physical Exam" },
    { date: "2023-12-15", description: "Blood Test" },
    { date: "2023-11-05", description: "Flu Vaccine" },
  ];

  return (
    <div className="card medical-history">
      <h2 className="section-title">Medical History</h2>
      <ul>
        {records.map((record, idx) => (
          <li key={idx}>
            <strong>{record.date}:</strong> {record.description}
          </li>
        ))}
      </ul>
    </div>
  );
};

export default MedicalHistory;

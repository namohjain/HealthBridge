import React from "react";
import "../App.css";

const Sidebar = () => {
  return (
    <div style={{ width: "220px", background: "#002f4b", color: "#fff", padding: "1rem" }}>
      <h2>HealthBridge</h2>
      <ul style={{ listStyle: "none", padding: 0 }}>
        <li style={{ margin: "1rem 0" }}>Dashboard</li>
        <li style={{ margin: "1rem 0" }}>Appointments</li>
        <li style={{ margin: "1rem 0" }}>Records</li>
        <li style={{ margin: "1rem 0" }}>Messages</li>
      </ul>
    </div>
  );
};

export default Sidebar;

import React from "react";
import "./App.css";
import Sidebar from "./components/SideBar";
import PatientSummary from "./components/PatientSummary";
import MedicalHistory from "./components/MedicalHistory";
import Appointments from "./components/Appointments";
import Notifications from "./components/Notifications";

function App() {
  return (
    <div className="dashboard-container">
      <Sidebar />
      <main className="dashboard-content">
        <PatientSummary />
        <div className="dashboard-section-row">
          <MedicalHistory />
          <Appointments />
        </div>
        <Notifications />
      </main>
    </div>
  );
}

export default App;

package in.co.ehealth.care.controller;

import java.io.IOException;
import java.nio.file.Paths;

import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.Part;

import org.apache.log4j.Logger;

import in.co.ehealth.care.bean.BaseBean;
import in.co.ehealth.care.bean.PatientBean;
import in.co.ehealth.care.bean.InsuranceBean;
import in.co.ehealth.care.exception.ApplicationException;
import in.co.ehealth.care.exception.DuplicateRecordException;
import in.co.ehealth.care.model.DoctorModel;
import in.co.ehealth.care.model.InsuranceModel;
import in.co.ehealth.care.util.DataUtility;
import in.co.ehealth.care.util.DataValidator;
import in.co.ehealth.care.util.PropertyReader;
import in.co.ehealth.care.util.ServletUtility;

/**
 * Servlet implementation class InsuranceCtl
 */

@WebServlet(name = "InsuranceCtl", urlPatterns = { "/ctl/insurance" })
public class InsuranceCtl extends BaseCtl {
	private static final long serialVersionUID = 1L;

	private static Logger log = Logger.getLogger(InsuranceCtl.class);
	
	

	@Override
	protected void preload(HttpServletRequest request) {
		try {
			request.setAttribute("doctorList", new DoctorModel().list());
		} catch (ApplicationException e) {
			e.printStackTrace();
		}
	}

	protected boolean validate(HttpServletRequest request) {

		log.debug("InsuranceCtl Method validate Started");

		boolean pass = true;
		
		if (DataValidator.isNull(request.getParameter("name"))) {
			request.setAttribute("name", PropertyReader.getValue("error.require", "Name"));
			pass = false;
		}
		
		if (DataValidator.isNull(request.getParameter("companyName"))) {
			request.setAttribute("companyName", PropertyReader.getValue("error.require", "Company Name"));
			pass = false;
		}
		
		if (DataValidator.isNull(request.getParameter("insuranceAmount"))) {
			request.setAttribute("insuranceAmount", PropertyReader.getValue("error.require", "Insurance Amount"));
			pass = false;
		}
		
		if (DataValidator.isNull(request.getParameter("endDate"))) {
			request.setAttribute("endDate", PropertyReader.getValue("error.require", "End Date"));
			pass = false;
		}
		
		log.debug("InsuranceCtl Method validate Ended");

		return pass;
	}

	@Override
	protected BaseBean populateBean(HttpServletRequest request) {

		log.debug("InsuranceCtl Method populatebean Started");

		InsuranceBean bean = new InsuranceBean();
		bean.setId(DataUtility.getLong(request.getParameter("id")));
		bean.setName(DataUtility.getString(request.getParameter("name")));
		bean.setCompanyName(DataUtility.getString(request.getParameter("companyName")));
		bean.setInsuranceAmount(DataUtility.getString(request.getParameter("insuranceAmount")));
		bean.setEndDate(DataUtility.getDate(request.getParameter("endDate")));

		populateDTO(bean, request);

		log.debug("InsuranceCtl Method populatebean Ended");

		return bean;
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		log.debug("InsuranceCtl Method doGet Started");

		String op = DataUtility.getString(request.getParameter("operation"));

		InsuranceModel model = new InsuranceModel();

		long id = DataUtility.getLong(request.getParameter("id"));

		if (id > 0 || op != null) {

			InsuranceBean bean;
			try {
				bean = model.findByPK(id);

				ServletUtility.setBean(bean, request);

			} catch (ApplicationException e) {
				log.error(e);
				ServletUtility.handleException(e, request, response);
				return;
			}
		}
		ServletUtility.forward(getView(), request, response);
		log.debug("InsuranceCtl Method doGet Ended");

	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		log.debug("InsuranceCtl Method doPost Started");
		String op = DataUtility.getString(request.getParameter("operation")); // get model
		
		InsuranceModel model = new InsuranceModel();
		
		long id = DataUtility.getLong(request.getParameter("id"));
		if (OP_SAVE.equalsIgnoreCase(op)) {
			InsuranceBean bean = (InsuranceBean) populateBean(request);
			PatientBean pBean = (PatientBean) request.getSession().getAttribute("patient");
			bean.setPatientId(pBean.getId());
			try {
				if (id > 0) {
					model.update(bean);
					ServletUtility.setSuccessMessage("Data is successfully Updated", request);
				} else {
					long pk = model.add(bean);
					ServletUtility.setSuccessMessage("Data is successfully saved", request);
				}
			} catch (ApplicationException e) {
				log.error(e);
				ServletUtility.handleException(e, request, response);
				return;
			} catch (DuplicateRecordException e) {
				ServletUtility.setBean(bean, request);
				ServletUtility.setErrorMessage(e.getMessage(), request);
			}
			ServletUtility.forward(getView(), request, response);
		} else if (OP_DELETE.equalsIgnoreCase(op)) {
			InsuranceBean bean = (InsuranceBean) populateBean(request);
			try {
				model.delete(bean);
				ServletUtility.redirect(EHCView.INSURANCE_LIST_CTL, request, response);
				return;
			} catch (ApplicationException e) {
				log.error(e);
				ServletUtility.handleException(e, request, response);
				return;
			}
		} else if (OP_CANCEL.equalsIgnoreCase(op)) {
			ServletUtility.redirect(EHCView.INSURANCE_LIST_CTL, request, response);
		} else if (OP_RESET.equalsIgnoreCase(op)) {
			ServletUtility.redirect(EHCView.INSURANCE_CTL, request, response);
			return;
		}
		ServletUtility.forward(getView(), request, response);
		log.debug("InsuranceCtl Method doPostEnded");
	}

	@Override
	protected String getView() {
		return EHCView.INSURANCE_VIEW;
	}

}

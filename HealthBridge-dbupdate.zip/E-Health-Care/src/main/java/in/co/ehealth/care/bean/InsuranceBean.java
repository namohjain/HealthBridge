package in.co.ehealth.care.bean;

import java.util.Date;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class InsuranceBean extends BaseBean {
	
	private long patientId;
	private String patientName;
	private String name;
	private String companyName;
	private String insuranceAmount;
	private Date endDate;

	@Override
	public String getKey() {
		return null;
	}

	@Override
	public String getValue() {
		return null;
	}

}

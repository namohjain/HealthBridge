package in.co.ehealth.care.bean;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class RoomBean extends BaseBean {
	
	private long wardId;
	private String wardName;
	private String roomNo;
	private String description;

	@Override
	public String getKey() {
		return String.valueOf(id);
	}

	@Override
	public String getValue() {
		return roomNo;
	}

}
